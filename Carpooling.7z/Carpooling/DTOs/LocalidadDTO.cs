﻿using System.Text.RegularExpressions;


namespace DTOs
{
    public class LocalidadDTO
    {
        public string CodPostal { get; set; }
        public string Nombre { get; set; }

    }
}

